
**
Step 1.  user will open application . scan product barcode 
	 it will get all detail over user table 
Note: No need to give code for barcode it can be called from application only since it present in all phone

step2 After all product list get ready .customer can  pay by any way . Important thing Quantity of product must be decrement from DB 

**

  
**default password is 1234.**  
